import { useState } from 'react';
import LoginPage from './components/LoginPage';
import BabyInfoPage from './components/BabyInfoPage';
import Dashboard from './components/Dashboard';

export default function App() {
  const [currentScreen, setCurrentScreen] = useState<'login' | 'babyInfo' | 'dashboard'>('login');
  const [parentData, setParentData] = useState({ mobile: '', location: '' });
  const [babyData, setBabyData] = useState({ name: '', years: 0, months: 0, totalMonths: 0 });

  const handleLogin = (mobile: string, location: string) => {
    setParentData({ mobile, location });
    setCurrentScreen('babyInfo');
  };

  const handleBabyInfo = (name: string, years: number, months: number) => {
    const totalMonths = years * 12 + months;
    setBabyData({ name, years, months, totalMonths });
    setCurrentScreen('dashboard');
  };

  return (
    <div className="min-h-screen">
      {currentScreen === 'login' && <LoginPage onContinue={handleLogin} />}
      {currentScreen === 'babyInfo' && <BabyInfoPage onContinue={handleBabyInfo} />}
      {currentScreen === 'dashboard' && <Dashboard parentData={parentData} babyData={babyData} />}
    </div>
  );
}
