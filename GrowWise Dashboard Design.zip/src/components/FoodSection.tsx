import { Card } from './ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from './ui/table';

interface FoodSectionProps {
  babyName: string;
  ageGroup: string;
  formattedAge: string;
}

export default function FoodSection({ babyName, ageGroup, formattedAge }: FoodSectionProps) {
  // Complete food data for all age groups
  const allFoodData: { [key: string]: { recommendedFoods: string; nutrients: string; tips: string } } = {
    '0-3': {
      recommendedFoods: 'Breast milk or formula exclusively',
      nutrients: 'Complete nutrition, Antibodies, DHA, Iron',
      tips: 'Feed on demand, typically 8-12 times per day. Breast milk provides all necessary nutrients.',
    },
    '3-6': {
      recommendedFoods: 'Breast milk or formula primarily, can introduce water',
      nutrients: 'Complete nutrition, Antibodies, Calcium, Vitamin D',
      tips: 'Continue exclusive breast milk or formula. Prepare for solid foods introduction around 6 months.',
    },
    '6-12': {
      recommendedFoods: 'Mashed fruits (banana, apple, pear), soft rice cereal, pureed vegetables (carrots, sweet potato), yogurt, breast milk',
      nutrients: 'Protein, Calcium, Iron, Vitamin A, Vitamin C, Fiber',
      tips: 'Introduce one new food at a time, waiting 3-5 days between each. Start with single-ingredient purees.',
    },
    '12-24': {
      recommendedFoods: 'Soft cooked foods, scrambled eggs, whole milk yogurt, ripe bananas, cooked dal, soft pasta, cheese, minced chicken',
      nutrients: 'Protein, Calcium, Iron, Zinc, Vitamin B12, Healthy fats',
      tips: 'Offer 3 meals plus 2 snacks daily. Include finger foods to develop motor skills. Transition to whole milk.',
    },
    '24-48': {
      recommendedFoods: 'Whole grains (brown rice, oats), variety of fruits and vegetables, lean meats, fish, eggs, nuts (if no allergies), legumes, dairy products',
      nutrients: 'Fiber, Protein, Vitamins A, C, D, E, Omega-3, Iron, Calcium',
      tips: 'Establish regular meal times. Encourage self-feeding. Offer colorful, varied foods to build healthy habits.',
    },
    '48+': {
      recommendedFoods: 'Balanced diet with whole grains, fresh fruits, vegetables, lean proteins (chicken, fish, tofu), nuts, seeds, dairy, healthy fats',
      nutrients: 'All essential nutrients, Fiber, Protein, Vitamins, Minerals, Antioxidants',
      tips: 'Maintain regular meal schedule. Limit processed foods and sugar. Encourage water intake and physical activity.',
    },
  };

  const currentFoodData = allFoodData[ageGroup] || allFoodData['48+'];

  const ageGroupLabels: { [key: string]: string } = {
    '0-3': '0-3 months',
    '3-6': '3-6 months',
    '6-12': '6-12 months',
    '12-24': '12-24 months',
    '24-48': '24-48 months',
    '48+': '48+ months',
  };

  return (
    <div>
      <div className="mb-6">
        <h3 className="text-2xl text-gray-800 mb-2">
          Recommended Foods for {babyName}, Age {formattedAge}
        </h3>
        <p className="text-gray-600">Personalized nutrition guide for {babyName}'s healthy growth</p>
      </div>

      <Card className="rounded-2xl shadow-lg border-0 overflow-hidden mb-6">
        <div className="bg-gradient-to-r from-[#007BFF] to-[#00BFFF] p-6">
          <h4 className="text-white text-xl mb-2">Age Group: {ageGroupLabels[ageGroup]}</h4>
          <p className="text-white/90">Showing recommendations specifically for this age range</p>
        </div>
        <div className="p-6 space-y-6">
          <div>
            <h5 className="text-gray-800 mb-2">Recommended Foods</h5>
            <p className="text-gray-700 leading-relaxed">{currentFoodData.recommendedFoods}</p>
          </div>
          <div>
            <h5 className="text-gray-800 mb-2">Key Nutrients</h5>
            <p className="text-gray-700 leading-relaxed">{currentFoodData.nutrients}</p>
          </div>
          <div className="bg-blue-50 rounded-xl p-4 border border-blue-200">
            <h5 className="text-[#007BFF] mb-2">💡 Feeding Tips for {babyName}</h5>
            <p className="text-gray-700 leading-relaxed">{currentFoodData.tips}</p>
          </div>
        </div>
      </Card>

      <div className="mt-6 p-4 bg-green-50 rounded-xl border border-green-200">
        <p className="text-gray-700">
          <span className="text-green-600">✓ Great job!</span> You're providing {babyName} with age-appropriate nutrition. 
          Always introduce new foods one at a time and consult your pediatrician for personalized advice.
        </p>
      </div>
    </div>
  );
}
