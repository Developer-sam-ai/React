import { useState } from 'react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Baby } from 'lucide-react';

interface LoginPageProps {
  onContinue: (mobile: string, location: string) => void;
}

export default function LoginPage({ onContinue }: LoginPageProps) {
  const [mobile, setMobile] = useState('');
  const [location, setLocation] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (mobile && location) {
      onContinue(mobile, location);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-[#007BFF] via-[#0095FF] to-[#00BFFF] p-4">
      <div className="w-full max-w-md">
        {/* Logo and Header */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-16 h-16 bg-white rounded-full mb-4 shadow-lg">
            <Baby className="w-8 h-8 text-[#007BFF]" />
          </div>
          <h1 className="text-white text-4xl mb-2">GrowWise</h1>
          <p className="text-white/90 text-lg">Smart Parenting Starts Here</p>
        </div>

        {/* Login Form */}
        <div className="bg-white rounded-2xl shadow-2xl p-8">
          <h2 className="text-2xl text-gray-800 mb-6 text-center">Welcome</h2>
          <form onSubmit={handleSubmit} className="space-y-5">
            <div>
              <Label htmlFor="mobile" className="text-gray-700">Mobile Number</Label>
              <Input
                id="mobile"
                type="tel"
                placeholder="Enter your mobile number"
                value={mobile}
                onChange={(e) => setMobile(e.target.value)}
                className="mt-1.5 border-gray-300 focus:border-[#007BFF] focus:ring-[#007BFF]"
                required
              />
            </div>
            <div>
              <Label htmlFor="location" className="text-gray-700">Location / Native Place</Label>
              <Input
                id="location"
                type="text"
                placeholder="Enter your location"
                value={location}
                onChange={(e) => setLocation(e.target.value)}
                className="mt-1.5 border-gray-300 focus:border-[#007BFF] focus:ring-[#007BFF]"
                required
              />
            </div>
            <Button
              type="submit"
              className="w-full bg-gradient-to-r from-[#007BFF] to-[#00BFFF] hover:from-[#0066DD] hover:to-[#00A5E5] text-white py-6 rounded-xl shadow-lg"
            >
              Continue
            </Button>
          </form>
        </div>

        <p className="text-center text-white/80 text-sm mt-6">
          Your journey to smart parenting begins here
        </p>
      </div>
    </div>
  );
}
