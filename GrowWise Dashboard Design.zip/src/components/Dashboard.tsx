import { useState } from 'react';
import { Apple, Activity, Scale, Lightbulb, FileText, Menu, X } from 'lucide-react';
import FoodSection from './FoodSection';
import DiseaseSection from './DiseaseSection';
import BMISection from './BMISection';
import InsightsSection from './InsightsSection';
import ReportsSection from './ReportsSection';

interface DashboardProps {
  parentData: { mobile: string; location: string };
  babyData: { name: string; years: number; months: number; totalMonths: number };
}

type Section = 'food' | 'disease' | 'bmi' | 'insights' | 'reports';
type AgeGroup = '0-3' | '3-6' | '6-12' | '12-24' | '24-48' | '48+';

// Utility function to format age
const formatAge = (years: number, months: number): string => {
  if (years === 0) {
    return `${months} ${months === 1 ? 'month' : 'months'}`;
  } else if (months === 0) {
    return `${years} ${years === 1 ? 'year' : 'years'}`;
  } else {
    return `${years} ${years === 1 ? 'year' : 'years'} ${months} ${months === 1 ? 'month' : 'months'}`;
  }
};

// Utility function to determine age group
const getAgeGroup = (totalMonths: number): AgeGroup => {
  if (totalMonths <= 3) return '0-3';
  if (totalMonths <= 6) return '3-6';
  if (totalMonths <= 12) return '6-12';
  if (totalMonths <= 24) return '12-24';
  if (totalMonths <= 48) return '24-48';
  return '48+';
};

export default function Dashboard({ parentData, babyData }: DashboardProps) {
  const [activeSection, setActiveSection] = useState<Section>('food');
  const [sidebarOpen, setSidebarOpen] = useState(false);

  const formattedAge = formatAge(babyData.years, babyData.months);
  const babyAgeGroup = getAgeGroup(babyData.totalMonths);

  const menuItems = [
    { id: 'food' as Section, label: 'Food', icon: Apple },
    { id: 'disease' as Section, label: 'Disease', icon: Activity },
    { id: 'bmi' as Section, label: 'Body Mass Index', icon: Scale },
    { id: 'insights' as Section, label: 'Insights', icon: Lightbulb },
    { id: 'reports' as Section, label: 'Reports', icon: FileText },
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Mobile Menu Button */}
      <button
        onClick={() => setSidebarOpen(!sidebarOpen)}
        className="lg:hidden fixed top-4 left-4 z-50 p-2 bg-white rounded-lg shadow-lg"
      >
        {sidebarOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
      </button>

      {/* Sidebar */}
      <aside
        className={`fixed left-0 top-0 h-full bg-white shadow-xl z-40 transition-transform duration-300 ${
          sidebarOpen ? 'translate-x-0' : '-translate-x-full'
        } lg:translate-x-0 w-64`}
      >
        <div className="p-6 border-b border-gray-200">
          <h1 className="text-2xl bg-gradient-to-r from-[#007BFF] to-[#00BFFF] bg-clip-text text-transparent">
            GrowWise
          </h1>
          <p className="text-gray-500 text-sm mt-1">Smart Parenting</p>
        </div>

        <nav className="p-4 space-y-2">
          {menuItems.map((item) => {
            const Icon = item.icon;
            return (
              <button
                key={item.id}
                onClick={() => {
                  setActiveSection(item.id);
                  setSidebarOpen(false);
                }}
                className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all ${
                  activeSection === item.id
                    ? 'bg-gradient-to-r from-[#007BFF] to-[#00BFFF] text-white shadow-lg'
                    : 'text-gray-700 hover:bg-gray-100'
                }`}
              >
                <Icon className="w-5 h-5" />
                <span>{item.label}</span>
              </button>
            );
          })}
        </nav>
      </aside>

      {/* Main Content */}
      <div className="lg:ml-64 min-h-screen">
        {/* Header */}
        <header className="bg-white shadow-sm border-b border-gray-200 p-6 lg:p-8">
          <div className="max-w-7xl">
            <h2 className="text-3xl text-gray-800">Welcome, {babyData.name} & Parent!</h2>
            <p className="text-gray-600 mt-1">
              {babyData.name} is {formattedAge} old
            </p>
          </div>
        </header>

        {/* Content Area */}
        <main className="p-6 lg:p-8">
          <div className="max-w-7xl mx-auto">
            {activeSection === 'food' && (
              <FoodSection 
                babyName={babyData.name} 
                ageGroup={babyAgeGroup}
                formattedAge={formattedAge}
              />
            )}
            {activeSection === 'disease' && (
              <DiseaseSection 
                babyName={babyData.name}
                ageGroup={babyAgeGroup}
                formattedAge={formattedAge}
              />
            )}
            {activeSection === 'bmi' && (
              <BMISection 
                babyName={babyData.name}
                totalMonths={babyData.totalMonths}
                formattedAge={formattedAge}
              />
            )}
            {activeSection === 'insights' && (
              <InsightsSection 
                babyName={babyData.name}
                formattedAge={formattedAge}
              />
            )}
            {activeSection === 'reports' && (
              <ReportsSection 
                babyName={babyData.name}
                formattedAge={formattedAge}
              />
            )}
          </div>
        </main>
      </div>
    </div>
  );
}
