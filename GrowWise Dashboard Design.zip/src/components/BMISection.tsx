import { Card } from './ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from './ui/table';
import { Button } from './ui/button';
import { Save } from 'lucide-react';

interface BMISectionProps {
  babyName: string;
  totalMonths: number;
  formattedAge: string;
}

export default function BMISection({ babyName, totalMonths, formattedAge }: BMISectionProps) {
  // Complete BMI data for all ages
  const allBmiData = [
    {
      age: '0-3 months',
      idealWeight: '3.5-5.5 kg',
      idealHeight: '50-60 cm',
      bmiRange: '12-16',
      maxMonths: 3,
    },
    {
      age: '3-6 months',
      idealWeight: '5.5-7.5 kg',
      idealHeight: '60-67 cm',
      bmiRange: '14-17',
      maxMonths: 6,
    },
    {
      age: '6-12 months',
      idealWeight: '7.5-10 kg',
      idealHeight: '67-75 cm',
      bmiRange: '15-18',
      maxMonths: 12,
    },
    {
      age: '12-18 months',
      idealWeight: '9-12 kg',
      idealHeight: '75-82 cm',
      bmiRange: '15-18',
      maxMonths: 18,
    },
    {
      age: '18-24 months',
      idealWeight: '10-13 kg',
      idealHeight: '82-87 cm',
      bmiRange: '15-18',
      maxMonths: 24,
    },
    {
      age: '2-3 years',
      idealWeight: '12-15 kg',
      idealHeight: '85-95 cm',
      bmiRange: '15-17',
      maxMonths: 36,
    },
    {
      age: '3-4 years',
      idealWeight: '14-18 kg',
      idealHeight: '95-103 cm',
      bmiRange: '14-17',
      maxMonths: 48,
    },
    {
      age: '4-5 years',
      idealWeight: '16-20 kg',
      idealHeight: '100-110 cm',
      bmiRange: '14-17',
      maxMonths: 60,
    },
    {
      age: '5-6 years',
      idealWeight: '18-23 kg',
      idealHeight: '107-117 cm',
      bmiRange: '14-17',
      maxMonths: 72,
    },
    {
      age: '6-7 years',
      idealWeight: '20-26 kg',
      idealHeight: '113-123 cm',
      bmiRange: '14-18',
      maxMonths: 84,
    },
    {
      age: '7-8 years',
      idealWeight: '22-30 kg',
      idealHeight: '119-129 cm',
      bmiRange: '14-18',
      maxMonths: 96,
    },
    {
      age: '8-9 years',
      idealWeight: '25-34 kg',
      idealHeight: '124-134 cm',
      bmiRange: '15-19',
      maxMonths: 108,
    },
    {
      age: '9-10 years',
      idealWeight: '28-38 kg',
      idealHeight: '129-139 cm',
      bmiRange: '15-19',
      maxMonths: 120,
    },
  ];

  // Filter BMI data based on baby's age
  const getFilteredBmiData = () => {
    const babyYears = Math.floor(totalMonths / 12);
    
    // If baby is 5 years or younger, show data from 0 to 5 years
    if (totalMonths <= 60) {
      return allBmiData.filter(item => item.maxMonths <= 60);
    }
    
    // If baby is older than 5 years, show a centered range around their age
    // Show from (babyYears - 2) to (babyYears + 1)
    const minYear = Math.max(5, babyYears - 2); // Start from at least year 5
    const maxYear = babyYears + 2;
    
    const minMonths = minYear * 12;
    const maxMonths = maxYear * 12;
    
    return allBmiData.filter(item => item.maxMonths >= minMonths && item.maxMonths <= maxMonths);
  };

  const bmiData = getFilteredBmiData();

  const handleSaveData = () => {
    alert(`Data saved successfully! ${babyName}'s growth metrics have been recorded.`);
  };

  const isCurrentAge = (maxMonths: number, prevMaxMonths?: number) => {
    const minMonths = prevMaxMonths || 0;
    return totalMonths > minMonths && totalMonths <= maxMonths;
  };

  return (
    <div>
      <div className="mb-6 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h3 className="text-2xl text-gray-800 mb-2">Body Mass Index (BMI) for {babyName}</h3>
          <p className="text-gray-600">Growth standards and healthy weight ranges - {babyName} is {formattedAge}</p>
        </div>
        <Button
          onClick={handleSaveData}
          className="bg-gradient-to-r from-[#007BFF] to-[#00BFFF] hover:from-[#0066DD] hover:to-[#00A5E5] text-white rounded-xl shadow-lg"
        >
          <Save className="w-4 h-4 mr-2" />
          Save Data
        </Button>
      </div>

      <Card className="rounded-2xl shadow-lg border-0 overflow-hidden">
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow className="bg-gradient-to-r from-[#007BFF] to-[#00BFFF]">
                <TableHead className="text-white">Age</TableHead>
                <TableHead className="text-white">Ideal Weight</TableHead>
                <TableHead className="text-white">Ideal Height</TableHead>
                <TableHead className="text-white">BMI Range</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {bmiData.map((row, index) => {
                const prevMaxMonths = index > 0 ? bmiData[index - 1].maxMonths : 0;
                const highlighted = isCurrentAge(row.maxMonths, prevMaxMonths);
                
                return (
                  <TableRow 
                    key={index} 
                    className={`hover:bg-blue-50 transition-colors ${
                      highlighted ? 'bg-blue-100' : ''
                    }`}
                  >
                    <TableCell className="text-gray-800">{row.age}</TableCell>
                    <TableCell className="text-gray-700">{row.idealWeight}</TableCell>
                    <TableCell className="text-gray-700">{row.idealHeight}</TableCell>
                    <TableCell className="text-gray-700">{row.bmiRange}</TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        </div>
      </Card>

      <div className="mt-6 p-4 bg-green-50 rounded-xl border border-green-200">
        <p className="text-gray-700">
          <span className="text-green-600">✓ Note for {babyName}:</span> These are general guidelines. Every child grows at their own pace, and {babyName} is unique! Regular pediatric checkups are essential to monitor {babyName}'s individual growth pattern. You're doing great!
        </p>
      </div>
    </div>
  );
}
