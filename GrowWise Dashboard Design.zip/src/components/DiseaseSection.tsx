import { Card } from './ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from './ui/table';

interface DiseaseSectionProps {
  babyName: string;
  ageGroup: string;
  formattedAge: string;
}

export default function DiseaseSection({ babyName, ageGroup, formattedAge }: DiseaseSectionProps) {
  // Disease data organized by age group
  const diseaseByAgeGroup: { [key: string]: Array<{ disease: string; symptoms: string; prevention: string }> } = {
    '0-3': [
      {
        disease: 'Colic',
        symptoms: 'Excessive crying (3+ hours), fussiness, gas, pulling legs to chest',
        prevention: 'Proper feeding techniques, burping after feeds, gentle tummy massage',
      },
      {
        disease: 'Diaper Rash',
        symptoms: 'Red, irritated skin in diaper area, discomfort during changes',
        prevention: 'Frequent diaper changes, air drying, barrier creams, gentle wipes',
      },
      {
        disease: 'Jaundice',
        symptoms: 'Yellowish skin and eyes, sleepiness, poor feeding',
        prevention: 'Adequate feeding, monitor bilirubin levels, sunlight exposure as advised',
      },
      {
        disease: 'Cradle Cap',
        symptoms: 'Scaly, crusty patches on scalp, yellowish or white scales',
        prevention: 'Gentle shampooing, soft brush, baby oil massage',
      },
    ],
    '3-6': [
      {
        disease: 'Teething Discomfort',
        symptoms: 'Drooling, irritability, gum swelling, mild fever, chewing on objects',
        prevention: 'Teething toys, cold washcloth, gentle gum massage',
      },
      {
        disease: 'Ear Infection',
        symptoms: 'Ear pulling, fever, fussiness, trouble sleeping, fluid drainage',
        prevention: 'Avoid smoke exposure, breastfeeding, keep ears dry',
      },
      {
        disease: 'Respiratory Infections',
        symptoms: 'Congestion, coughing, runny nose, difficulty feeding',
        prevention: 'Hand hygiene, avoid sick contacts, breastfeeding immunity',
      },
      {
        disease: 'Reflux',
        symptoms: 'Frequent spitting up, arching back, fussiness during feeds',
        prevention: 'Upright position after feeds, smaller frequent meals, burping',
      },
    ],
    '6-12': [
      {
        disease: 'Common Cold',
        symptoms: 'Runny nose, sneezing, mild fever, cough, reduced appetite',
        prevention: 'Hand washing, avoid sick contacts, maintain humidity, adequate rest',
      },
      {
        disease: 'Diarrhea',
        symptoms: 'Loose watery stools, stomach cramps, dehydration signs',
        prevention: 'Clean water, proper food handling, hand hygiene, clean utensils',
      },
      {
        disease: 'Roseola',
        symptoms: 'High fever followed by rash, irritability',
        prevention: 'Avoid contact with infected children, good hygiene',
      },
      {
        disease: 'Food Allergies',
        symptoms: 'Rash, hives, vomiting, diarrhea after new foods',
        prevention: 'Introduce foods one at a time, watch for reactions, consult doctor',
      },
    ],
    '12-24': [
      {
        disease: 'Hand, Foot, and Mouth Disease',
        symptoms: 'Fever, mouth sores, rash on hands and feet, sore throat',
        prevention: 'Frequent hand washing, avoid sharing utensils, disinfect toys',
      },
      {
        disease: 'Stomach Bug (Gastroenteritis)',
        symptoms: 'Vomiting, diarrhea, fever, stomach pain, dehydration',
        prevention: 'Hand hygiene, clean food preparation, avoid contaminated water',
      },
      {
        disease: 'Croup',
        symptoms: 'Barking cough, hoarse voice, breathing difficulty, stridor',
        prevention: 'Vaccination, avoid respiratory irritants, humidity',
      },
      {
        disease: 'Bronchiolitis',
        symptoms: 'Wheezing, rapid breathing, coughing, feeding difficulty',
        prevention: 'Hand washing, avoid smoke, limit exposure to sick individuals',
      },
    ],
    '24-48': [
      {
        disease: 'Strep Throat',
        symptoms: 'Severe sore throat, fever, swollen glands, difficulty swallowing',
        prevention: 'Hand washing, avoid sharing items, strengthen immunity',
      },
      {
        disease: 'Conjunctivitis (Pink Eye)',
        symptoms: 'Red or pink eyes, discharge, itching, tearing',
        prevention: 'Hand washing, avoid touching eyes, don\'t share towels',
      },
      {
        disease: 'Urinary Tract Infection',
        symptoms: 'Fever, pain during urination, frequent urination, abdominal pain',
        prevention: 'Proper hygiene, adequate hydration, regular bathroom breaks',
      },
      {
        disease: 'Chickenpox',
        symptoms: 'Itchy rash, blisters, fever, tiredness',
        prevention: 'Vaccination, avoid contact with infected individuals',
      },
    ],
    '48+': [
      {
        disease: 'Common Cold & Flu',
        symptoms: 'Fever, cough, congestion, body aches, fatigue',
        prevention: 'Annual flu shot, hand hygiene, healthy diet, adequate sleep',
      },
      {
        disease: 'Asthma Symptoms',
        symptoms: 'Wheezing, shortness of breath, chest tightness, coughing',
        prevention: 'Avoid triggers, clean environment, regular checkups',
      },
      {
        disease: 'Allergies',
        symptoms: 'Sneezing, itchy eyes, runny nose, skin rashes',
        prevention: 'Identify allergens, clean bedding, air purifiers, allergy testing',
      },
      {
        disease: 'Growing Pains',
        symptoms: 'Leg pain at night, no swelling or redness, affects both legs',
        prevention: 'Massage, stretching, warm compress, adequate rest',
      },
    ],
  };

  const currentDiseases = diseaseByAgeGroup[ageGroup] || diseaseByAgeGroup['48+'];

  const ageGroupLabels: { [key: string]: string } = {
    '0-3': '0-3 months',
    '3-6': '3-6 months',
    '6-12': '6-12 months',
    '12-24': '12-24 months',
    '24-48': '24-48 months',
    '48+': '48+ months',
  };

  return (
    <div>
      <div className="mb-6">
        <h3 className="text-2xl text-gray-800 mb-2">
          Common Diseases & Symptoms for {babyName}, Age {formattedAge}
        </h3>
        <p className="text-gray-600">Understanding age-specific health concerns for {babyName}</p>
      </div>

      <Card className="rounded-2xl shadow-lg border-0 overflow-hidden">
        <div className="bg-gradient-to-r from-[#007BFF] to-[#00BFFF] p-4">
          <p className="text-white">Showing conditions common in {ageGroupLabels[ageGroup]} age group</p>
        </div>
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow className="bg-gray-100">
                <TableHead className="text-gray-800">Common Condition</TableHead>
                <TableHead className="text-gray-800">Symptoms to Watch</TableHead>
                <TableHead className="text-gray-800">Prevention Tips</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {currentDiseases.map((row, index) => (
                <TableRow key={index} className="hover:bg-blue-50 transition-colors">
                  <TableCell className="text-gray-800">{row.disease}</TableCell>
                  <TableCell className="text-gray-700">{row.symptoms}</TableCell>
                  <TableCell className="text-gray-700">{row.prevention}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      </Card>

      <div className="mt-6 p-4 bg-yellow-50 rounded-xl border border-yellow-200">
        <p className="text-gray-700">
          <span className="text-yellow-600">⚠️ Important for {babyName}:</span> If your child shows severe symptoms like high fever (over 102°F), difficulty breathing, persistent vomiting, signs of dehydration, or unusual lethargy, please consult a doctor immediately. Trust your parental instincts!
        </p>
      </div>
    </div>
  );
}
