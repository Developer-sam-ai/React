import { useState } from 'react';
import { Card } from './ui/card';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { Button } from './ui/button';
import { CheckCircle2, AlertCircle, TrendingUp } from 'lucide-react';

interface ReportsSectionProps {
  babyName: string;
  formattedAge: string;
}

export default function ReportsSection({ babyName, formattedAge }: ReportsSectionProps) {
  const [formData, setFormData] = useState({
    height: '',
    weight: '',
    diet: '',
  });
  const [result, setResult] = useState<null | {
    status: 'healthy' | 'attention';
    message: string;
    bmi: string;
  }>(null);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const height = parseFloat(formData.height);
    const weight = parseFloat(formData.weight);
    
    if (height && weight) {
      // Calculate BMI (kg/m²)
      const heightInMeters = height / 100;
      const bmi = (weight / (heightInMeters * heightInMeters)).toFixed(1);
      
      // Simple logic for demonstration
      const bmiValue = parseFloat(bmi);
      
      if (bmiValue >= 14 && bmiValue <= 18) {
        setResult({
          status: 'healthy',
          message: `Excellent news! ${babyName}'s growth is perfectly healthy. Your baby is doing great—just keep including those nutritious fruits, vegetables, and whole grains. You're doing a wonderful job!`,
          bmi,
        });
      } else if (bmiValue < 14) {
        setResult({
          status: 'attention',
          message: `${babyName}'s BMI is slightly below the ideal range. This is okay—let's focus on nutrient-rich foods! Try adding more healthy fats like avocado, nut butters, and dairy. Include a bit more protein from eggs, lentils, and yogurt. You've got this!`,
          bmi,
        });
      } else {
        setResult({
          status: 'attention',
          message: `${babyName}'s BMI is slightly above the ideal range. No worries—small adjustments can help! Focus on including more green veggies, reduce sugary snacks, and encourage active playtime. Keep offering water instead of juice. You're doing great as a parent!`,
          bmi,
        });
      }
    }
  };

  return (
    <div>
      <div className="mb-6">
        <h3 className="text-2xl text-gray-800 mb-2">Health Reports for {babyName}</h3>
        <p className="text-gray-600">Track {babyName}'s growth and get personalized recommendations ({formattedAge})</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Input Form */}
        <Card className="rounded-2xl shadow-lg border-0 p-6">
          <h4 className="text-xl text-gray-800 mb-4">Enter Current Measurements</h4>
          <form onSubmit={handleSubmit} className="space-y-5">
            <div>
              <Label htmlFor="height" className="text-gray-700">Height (in cm)</Label>
              <Input
                id="height"
                type="number"
                step="0.1"
                placeholder="Enter height in cm"
                value={formData.height}
                onChange={(e) => setFormData({ ...formData, height: e.target.value })}
                className="mt-1.5 border-gray-300 focus:border-[#007BFF] focus:ring-[#007BFF]"
                required
              />
            </div>
            <div>
              <Label htmlFor="weight" className="text-gray-700">Weight (in kg)</Label>
              <Input
                id="weight"
                type="number"
                step="0.1"
                placeholder="Enter weight in kg"
                value={formData.weight}
                onChange={(e) => setFormData({ ...formData, weight: e.target.value })}
                className="mt-1.5 border-gray-300 focus:border-[#007BFF] focus:ring-[#007BFF]"
                required
              />
            </div>
            <div>
              <Label htmlFor="diet" className="text-gray-700">Daily Diet Summary</Label>
              <Textarea
                id="diet"
                placeholder="Describe what your baby ate today (e.g., milk, fruits, rice, vegetables)"
                value={formData.diet}
                onChange={(e) => setFormData({ ...formData, diet: e.target.value })}
                className="mt-1.5 border-gray-300 focus:border-[#007BFF] focus:ring-[#007BFF] min-h-24"
                required
              />
            </div>
            <Button
              type="submit"
              className="w-full bg-gradient-to-r from-[#007BFF] to-[#00BFFF] hover:from-[#0066DD] hover:to-[#00A5E5] text-white py-6 rounded-xl shadow-lg"
            >
              Generate Report
            </Button>
          </form>
        </Card>

        {/* Result Card */}
        {result && (
          <Card
            className={`rounded-2xl shadow-lg border-0 p-6 ${
              result.status === 'healthy'
                ? 'bg-gradient-to-br from-green-50 to-emerald-50 border border-green-200'
                : 'bg-gradient-to-br from-yellow-50 to-orange-50 border border-yellow-200'
            }`}
          >
            <div className="flex items-start gap-4 mb-6">
              {result.status === 'healthy' ? (
                <div className="p-3 rounded-xl bg-green-500 shadow-md">
                  <CheckCircle2 className="w-8 h-8 text-white" />
                </div>
              ) : (
                <div className="p-3 rounded-xl bg-yellow-500 shadow-md">
                  <AlertCircle className="w-8 h-8 text-white" />
                </div>
              )}
              <div>
                <h4 className="text-2xl text-gray-800 mb-2">
                  {result.status === 'healthy' ? 'Healthy Growth ✓' : 'Needs Slight Attention'}
                </h4>
                <p className="text-gray-600">BMI: {result.bmi}</p>
              </div>
            </div>

            <p className="text-gray-800 leading-relaxed mb-6">{result.message}</p>

            <div className="bg-white/60 rounded-xl p-4 border border-gray-200">
              <div className="flex items-center gap-2 mb-2">
                <TrendingUp className="w-5 h-5 text-[#007BFF]" />
                <span className="text-gray-800">Quick Tips:</span>
              </div>
              <ul className="space-y-2 text-gray-700 text-sm ml-7">
                <li>• Ensure 5-6 small meals throughout the day</li>
                <li>• Include colorful fruits and vegetables</li>
                <li>• Maintain regular sleep schedule</li>
                <li>• Encourage physical activity and play</li>
                <li>• Stay hydrated with water and milk</li>
              </ul>
            </div>
          </Card>
        )}

        {!result && (
          <Card className="rounded-2xl shadow-lg border-0 bg-gradient-to-br from-blue-50 to-cyan-50 p-8 flex items-center justify-center">
            <div className="text-center">
              <div className="inline-flex items-center justify-center w-16 h-16 bg-gradient-to-r from-[#007BFF] to-[#00BFFF] rounded-full mb-4">
                <TrendingUp className="w-8 h-8 text-white" />
              </div>
              <h4 className="text-xl text-gray-800 mb-2">Ready to Generate Report</h4>
              <p className="text-gray-600">
                Fill in the measurements to get a personalized health assessment for {babyName}
              </p>
            </div>
          </Card>
        )}
      </div>
    </div>
  );
}
