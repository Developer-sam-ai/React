import { useState } from 'react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Baby, Heart } from 'lucide-react';

interface BabyInfoPageProps {
  onContinue: (name: string, years: number, months: number) => void;
}

export default function BabyInfoPage({ onContinue }: BabyInfoPageProps) {
  const [name, setName] = useState('');
  const [years, setYears] = useState('0');
  const [months, setMonths] = useState('0');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (name) {
      onContinue(name, parseInt(years), parseInt(months));
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-[#007BFF] via-[#0095FF] to-[#00BFFF] p-4">
      <div className="w-full max-w-md">
        {/* Illustration */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-24 h-24 bg-white rounded-full mb-6 shadow-xl relative">
            <Baby className="w-12 h-12 text-[#007BFF]" />
            <Heart className="w-6 h-6 text-red-400 absolute -top-2 -right-2" />
          </div>
          <h2 className="text-white text-3xl mb-2">Tell us about your little one</h2>
          <p className="text-white/90">We'll personalize your experience</p>
        </div>

        {/* Baby Info Form */}
        <div className="bg-white rounded-2xl shadow-2xl p-8">
          <form onSubmit={handleSubmit} className="space-y-5">
            <div>
              <Label htmlFor="babyName" className="text-gray-700">Baby's Name</Label>
              <Input
                id="babyName"
                type="text"
                placeholder="Enter baby's name"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="mt-1.5 border-gray-300 focus:border-[#007BFF] focus:ring-[#007BFF]"
                required
              />
            </div>
            <div>
              <Label className="text-gray-700">Baby's Age</Label>
              <div className="grid grid-cols-2 gap-4 mt-1.5">
                <div>
                  <Label htmlFor="years" className="text-sm text-gray-600">Years</Label>
                  <Select value={years} onValueChange={setYears}>
                    <SelectTrigger id="years" className="mt-1 border-gray-300 focus:border-[#007BFF] focus:ring-[#007BFF]">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {[...Array(11)].map((_, i) => (
                        <SelectItem key={i} value={i.toString()}>
                          {i} {i === 1 ? 'year' : 'years'}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="months" className="text-sm text-gray-600">Months</Label>
                  <Select value={months} onValueChange={setMonths}>
                    <SelectTrigger id="months" className="mt-1 border-gray-300 focus:border-[#007BFF] focus:ring-[#007BFF]">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {[...Array(12)].map((_, i) => (
                        <SelectItem key={i} value={i.toString()}>
                          {i} {i === 1 ? 'month' : 'months'}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </div>
            <Button
              type="submit"
              className="w-full bg-gradient-to-r from-[#007BFF] to-[#00BFFF] hover:from-[#0066DD] hover:to-[#00A5E5] text-white py-6 rounded-xl shadow-lg"
            >
              Continue
            </Button>
          </form>
        </div>
      </div>
    </div>
  );
}
