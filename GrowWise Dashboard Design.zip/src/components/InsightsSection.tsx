import { Card } from './ui/card';
import { Heart, Baby, Smile, Sparkles, Sun, Leaf, Star, Users } from 'lucide-react';

interface InsightsSectionProps {
  babyName: string;
  formattedAge: string;
}

export default function InsightsSection({ babyName, formattedAge }: InsightsSectionProps) {
  const parentingInsights = [
    {
      icon: Baby,
      title: 'Every Child is Unique',
      message: `${babyName} will grow at their own beautiful pace. Comparing them to other children only creates unnecessary worry. Celebrate their individual milestones, whether they come early or take a little longer. Your child's journey is uniquely theirs.`,
      color: 'from-purple-500 to-pink-500',
      bgColor: 'bg-purple-50',
      borderColor: 'border-purple-200',
    },
    {
      icon: Heart,
      title: 'Let Them Explore & Fall',
      message: `Don't overprotect ${babyName}. Small falls, minor bumps, and little mistakes are part of learning. These experiences build resilience, confidence, and problem-solving skills. Your role is to create a safe environment, not to prevent every stumble.`,
      color: 'from-rose-500 to-red-500',
      bgColor: 'bg-rose-50',
      borderColor: 'border-rose-200',
    },
    {
      icon: Sun,
      title: 'Enjoy This Precious Era',
      message: `Being a parent is one of life's greatest gifts. These moments—the giggles, the first words, the tiny hands—they pass quickly. Cherish the chaos, embrace the mess, and be present. This is a chapter you'll look back on with the warmest memories.`,
      color: 'from-yellow-500 to-orange-500',
      bgColor: 'bg-yellow-50',
      borderColor: 'border-yellow-200',
    },
    {
      icon: Smile,
      title: 'Trust Your Instincts',
      message: `You know ${babyName} better than anyone else. While advice and guidelines are helpful, your parental instincts are powerful. If something feels right or wrong, trust that feeling. You're doing an amazing job, even on the hard days.`,
      color: 'from-green-500 to-emerald-500',
      bgColor: 'bg-green-50',
      borderColor: 'border-green-200',
    },
    {
      icon: Leaf,
      title: 'Independence Over Dependency',
      message: `Encourage ${babyName} to do things on their own, even if it takes longer or gets messy. Self-feeding, picking up toys, or choosing clothes—these small acts build independence and self-confidence that will serve them throughout life.`,
      color: 'from-teal-500 to-cyan-500',
      bgColor: 'bg-teal-50',
      borderColor: 'border-teal-200',
    },
    {
      icon: Star,
      title: 'Quality Time Over Perfection',
      message: `${babyName} doesn't need perfect parents—they need present ones. It's not about expensive toys or perfect routines. It's about your time, attention, and love. Play together, read together, laugh together. That's what they'll remember.`,
      color: 'from-indigo-500 to-blue-500',
      bgColor: 'bg-indigo-50',
      borderColor: 'border-indigo-200',
    },
  ];

  const idealParentingPrinciples = [
    {
      title: 'Consistency with Flexibility',
      description: 'Maintain routines but adapt when needed. Children thrive on predictability, yet life requires flexibility.',
    },
    {
      title: 'Positive Reinforcement',
      description: 'Praise efforts, not just results. Saying "You tried so hard!" builds growth mindset better than "You are so smart!"',
    },
    {
      title: 'Emotional Validation',
      description: 'All feelings are valid, even the difficult ones. Teach them to name and express emotions healthily.',
    },
    {
      title: 'Model, Do Not Lecture',
      description: 'Children learn by watching you. Show kindness, patience, and resilience in your daily actions.',
    },
    {
      title: 'Safe Environment, Free Exploration',
      description: 'Childproof the space, then let them explore. Supervision does not mean constant intervention.',
    },
    {
      title: 'Connection Before Correction',
      description: 'When challenges arise, connect emotionally first, then address behavior. Understanding precedes discipline.',
    },
  ];

  return (
    <div>
      <div className="mb-8">
        <h3 className="text-2xl text-gray-800 mb-2">Parenting Wisdom for {babyName}'s Journey</h3>
        <p className="text-gray-600">Thoughtful guidance for raising {babyName} ({formattedAge}) with love and wisdom</p>
      </div>

      {/* Main Parenting Insights */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
        {parentingInsights.map((insight, index) => {
          const Icon = insight.icon;
          return (
            <Card
              key={index}
              className={`rounded-2xl shadow-lg border ${insight.borderColor} ${insight.bgColor} p-6 hover:shadow-xl transition-all`}
            >
              <div className="flex items-start gap-4">
                <div className={`p-3 rounded-xl bg-gradient-to-br ${insight.color} shadow-md flex-shrink-0`}>
                  <Icon className="w-6 h-6 text-white" />
                </div>
                <div className="flex-1">
                  <h4 className="text-gray-800 text-lg mb-3">{insight.title}</h4>
                  <p className="text-gray-700 leading-relaxed">{insight.message}</p>
                </div>
              </div>
            </Card>
          );
        })}
      </div>

      {/* Ideal Parenting Principles */}
      <Card className="rounded-2xl shadow-lg border-0 overflow-hidden mb-8">
        <div className="bg-gradient-to-r from-[#007BFF] to-[#00BFFF] p-6">
          <div className="flex items-center gap-3">
            <Users className="w-8 h-8 text-white" />
            <h4 className="text-white text-2xl">Principles of Good Parenting</h4>
          </div>
        </div>
        <div className="p-8">
          <p className="text-gray-700 mb-6 text-lg leading-relaxed">
            Parenting is not about being perfect—it is about being present, patient, and loving. Here are timeless principles that create a nurturing environment for {babyName}:
          </p>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {idealParentingPrinciples.map((principle, index) => (
              <div key={index} className="bg-blue-50 rounded-xl p-5 border border-blue-200">
                <h5 className="text-[#007BFF] mb-2 flex items-center gap-2">
                  <span className="text-xl">•</span>
                  <span>{principle.title}</span>
                </h5>
                <p className="text-gray-700 leading-relaxed ml-6">{principle.description}</p>
              </div>
            ))}
          </div>
        </div>
      </Card>

      {/* Heartfelt Message */}
      <Card className="rounded-2xl shadow-lg border-0 bg-gradient-to-br from-pink-100 via-purple-100 to-blue-100 p-8">
        <div className="flex items-start gap-4 mb-4">
          <Sparkles className="w-10 h-10 text-[#007BFF] flex-shrink-0 mt-1" />
          <div>
            <h4 className="text-2xl text-gray-800 mb-4">A Message for You</h4>
            <p className="text-gray-800 leading-relaxed mb-4 text-lg">
              Raising {babyName} is the most important and beautiful work you will ever do. There will be challenging days, sleepless nights, and moments of doubt. That is completely normal.
            </p>
            <p className="text-gray-800 leading-relaxed mb-4 text-lg">
              Remember: You do not need to be a perfect parent. {babyName} needs you to be real, loving, and present. They need someone who tries, who learns, who apologizes when wrong, and who celebrates their uniqueness.
            </p>
            <p className="text-gray-800 leading-relaxed text-lg">
              These years are fleeting. One day, you will miss the mess, the noise, and even the chaos. So take a deep breath, give yourself grace, and enjoy this incredible journey. You are exactly the parent {babyName} needs.
            </p>
          </div>
        </div>
      </Card>
    </div>
  );
}
